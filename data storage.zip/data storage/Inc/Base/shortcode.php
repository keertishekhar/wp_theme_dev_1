<?php
/**
*@package DataStorage
*/
namespace Inc\Base;

class ShortCode extends Basecontroller
{
		
		public function register(){
			add_shortcode('feeding_calculator', array($this, 'shortCode'));
		}
		
		public function shortCode(){
			$content = include_once($this->plugin_path .'template/calculator.php');
		}
		
}
?>