<?php
/**
*@package DataStorage
*/
namespace Inc\Base;

use \Inc\Base\Basecontroller;

class Enqueue extends Basecontroller
{
  public function register(){
  		add_action( 'wp_enqueue_scripts', array($this, 'enqueue'));
  }
  public function enqueue(){
	wp_enqueue_script('mypluginangulerscript', 'https://ajax.googleapis.com/ajax/libs/angularjs/1.2.5/angular.min.js');
    wp_enqueue_style('bootstrap-1','https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css');
    wp_enqueue_script('bootstrap-2','https://code.jquery.com/jquery-3.3.1.slim.min.js');
    wp_enqueue_script('bootstrap-3','https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js');
    wp_enqueue_script('bootstrap-4','https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js');
    wp_enqueue_style( 'mypluginstyle', $this->plugin_url .'assets/mystyle.css');
    wp_enqueue_script( 'mypluginsctipt', $this->plugin_url .'assets/myscript.js');
    wp_enqueue_style( 'myfeedstyle', $this->plugin_url .'assets/feedstyle.css');
    wp_enqueue_script( 'myfeedsctipt', $this->plugin_url .'assets/feedscript.js');
  }

}
?>
