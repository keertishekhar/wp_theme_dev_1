var app = angular.module("app", []);
		app.controller("myController", function($scope) {
			$scope.calculator = {
			pet : "pet",
			resultDecimalLb : null,
			resultDecimalOz : null,
			resultFractionLb : null,
			resultFractionOz : null,
			resultFractionOzF : null
		// ounce fraction
		};
		var i = 'puppy';
		var chart = {
			puppy : {
				low : 4,
				moderate : 5,
				high : 6
			},
			adultDog : {
				low : 2,
				moderate : 2.5,
				high : 3
			},
			performance : {
				low : 3,
				moderate : 5.5,
				high : 6
			},
			senior : {
				low : 1.5,
				moderate : 1.75,
				high : 2
			},
			kitten : {
				low : 3.75,
				moderate : 5,
				high : 6.25
			},
			adultCat : {
				low : 2,
				moderate : 2.5,
				high : 3
			}
		};

		$scope.calculate = function() {

			var percent = null;
			if ($scope.calculator.pet && ($scope.calculator.dogAge || $scope.calculator.catAge) && $scope.calculator.activity && $scope.calculator.weight) {

				if ($scope.calculator.pet == 'dog') {
					percent = chart[$scope.calculator.dogAge][$scope.calculator.activity];
				} else {
					percent = chart[$scope.calculator.catAge][$scope.calculator.activity];
				}

			}
			// console.log(percent);
			if (percent == null) {
				$scope.calculator.resultDecimalLb = null;
				$scope.calculator.resultDecimalOz = null;
				$scope.calculator.resultFractionLb = null;
				$scope.calculator.resultFractionOz = null;
				$scope.calculator.resultFractionOzF = null;
			} else {
				if ($scope.active == 'Decimal') {
					$scope.calculator.resultFractionLb = null;
					$scope.calculator.resultFractionOz = null;
					$scope.calculator.resultFractionOzF = null;

					var food = poundsToOunces($scope.calculator.weight) * percent / 100;
					food.toFixed(0);
					// console.log('food', food);

					$scope.calculator.resultDecimalLb = Math.floor(food / 16);
					if ($scope.calculator.resultDecimalLb >= 1) {
						$scope.calculator.resultDecimalLb = (food / 16).toFixed(1);
						$scope.calculator.resultDecimalLb = parseFloat($scope.calculator.resultDecimalLb.toString())
						$scope.calculator.resultDecimalOz = 0;
					} else {
						$scope.calculator.resultDecimalOz = food;
					}

				}

				if ($scope.active == 'Fraction') {
					$scope.calculator.resultDecimalLb = null;
					$scope.calculator.resultDecimalOz = null;

					var food = poundsToOunces($scope.calculator.weight) * percent / 100;
					food.toFixed(0);
					$scope.calculator.resultFractionLb = Math.floor(food / 16);

					var remainder = food % 16;
					$scope.calculator.resultFractionOz = Math.floor(remainder);
					$scope.calculator.resultFractionOzF = closest(remainder - $scope.calculator.resultFractionOz);

				}
			}

		}

		var poundsToOunces = function(lbs) {
			return lbs * 16;
		}

		function closest(num) {
			var conversionArray = [ 0, 0.0625, 0.125, 0.1875, 0.25, 0.3125, 0.375, 0.4375, 0.5, 0.5625, 0.625, 0.6875, 0.75, 0.8125, 0.875, 0.9375 ];
			var minDiff = 1000;
			var ans;
			for (i = 0; i < 16; i++) {
				var m = Math.abs(num - conversionArray[i]);
				if (m < minDiff) {
					minDiff = m;
					ans = i;
				}
			}
			// console.log("closest", ans + 1);
			return ans;
		}

		// ----------- toggle Style 2 -----------//
		$scope.active = 'Decimal';
		$scope.setActive = function(type) {
			$scope.active = type;
		};
		$scope.isActive = function(type) {
			return type === $scope.active;
		};

		// --------
		$scope.scrollDown = function() {
			$timeout(function() {
				$ionicScrollDelegate.scrollBottom();
				// console.log('scroll');
			}, 300);
		}
		});