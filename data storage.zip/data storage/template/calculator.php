<div id="feedCalculator" ng-app="app" class="ng-scope">
		<div class="container ng-scope" ng-controller="myController">
			<h1 style="text-align:center;">Feeding Calculator</h1>
			<hr>			
			<form class="form-horizontal form-bordered ng-valid ng-dirty">
				<div class="col-md-12">
					<div class="row">
						<div class="col-md-4">
							<label class="control-label" for="inputSuccess">My pet is a:</label>
						</div>
						<div class="col-md-7">
						<div class="row">
							<div class="col-md-5 cc-selector">
								<input id="dog" type="radio" value="dog" ng-model="calculator.pet" ng-change="calculate()" class="ng-valid ng-dirty" name="004">
									<label class="drinkcard-cc" for="dog">
										<img class="dog" src="<?php echo plugin_dir_url( dirname(__FILE__, 1)).'assets/images/dog.png';?>" >
									</label>
							</div>
							<div class="col-md-5 cc-selector">
								<input id="cat" type="radio" value="cat" ng-model="calculator.pet" ng-change="calculate()" class="ng-valid ng-dirty" name="005">
									<label class="drinkcard-cc" for="cat">
										<img class="cat" src="<?php echo plugin_dir_url( dirname(__FILE__, 1)).'assets/images/cat.png';?>"  >
									</label>
							</div>
						</div>
						</div>
					</div>
				</div>
				<!-- ngIf: calculator.pet=='dog' -->
				<div class="col-md-12" ng-if="calculator.pet=='dog'">
					<div class="row">	
						<div class="col-md-4">
							<label class="control-label-input" for="inputSuccess">My dog's stage:</label>
						</div>
						<div class="col-md-7">
							<select class="form-control input-lg mb-md" ng-model="calculator.dogAge" ng-change="calculate()">
								<option class="options" value='puppy'>Puppy</option>
								<option class="options" value='adultDog'>Adult</option>
								<option class="options" value='senior'>Senior</option>
								<option class="options" value='performance'>Extremly Active</option>
							</select>
						</div>
					</div>
				</div>						
				<!-- ngIf: calculator.pet=='cat' -->
				<div class="col-md-12" ng-if="calculator.pet==&#39;cat&#39;">
					<div class="row">
						<div class="col-md-4">
							<label class="control-label-input" for="inputSuccess">My cat's stage:</label>
						</div>
						<div class="col-md-7">
							<select class="form-control input-lg mb-md ng-valid ng-dirty" ng-model="calculator.catAge" ng-change="calculate()">
								<option class="options" value="kitten">Kitten over 8 weeks</option>
								<option class="options" value="adultCat">Adult</option>
							</select>
						</div>
					</div>
				</div>
				<!-- end ngIf: calculator.pet=='cat' -->							
				<!-- ngIf: calculator.dogAge || calculator.catAge -->							
				<!-- background-image:url(https://tailblazerspets.com/img/activity_indicator_low.png);
					 background-image:url(https://tailblazerspets.com/img/activity_indicator_medium.png);
					 background-image:url(https://tailblazerspets.com/img/activity_indicator_high.png); -->
				<div class="col-md-12" ng-if="calculator.dogAge || calculator.catAge">
					<div class="row">
						<div class="col-md-4">
							<label class="control-label" for="inputSuccess">Activity level:</label>
						</div>
						<div class="col-md-7">
							<div class="cc-selector">
								<div class="row">
									<ul class="ul-list">
										<li>
												<input id="low" type="radio" value="low" ng-model="calculator.activity" ng-change="calculate()" class="ng-pristine ng-valid" name="008">
													<label class="drinkcard-cc" for="low">
														<img class="" src="<?php echo plugin_dir_url( dirname(__FILE__, 1)).'assets/images/circle1.png';?>">
													</label>
										</li>
										<li>
												<input id="moderate" type="radio" value="moderate" ng-model="calculator.activity" ng-change="calculate()" class="ng-pristine ng-valid" name="009">
													<label class="drinkcard-cc" for="moderate">
														<img class="" src="<?php echo plugin_dir_url( dirname(__FILE__, 1)).'assets/images/circle2.png';?>">
													</label>
										</li>
										<li>
												<input id="high" type="radio" value="high" ng-model="calculator.activity" ng-change="calculate()" class="ng-valid ng-dirty" name="00A">
													<label class="drinkcard-cc" for="high">
														<img class="" src="<?php echo plugin_dir_url( dirname(__FILE__, 1)).'assets/images/circle3.png';?>">
													</label>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div><!-- end ngIf: calculator.dogAge || calculator.catAge -->							
				<!-- ngIf: calculator.activity -->
				<div class="col-md-12 ng-scope" ng-if="calculator.activity">
					<div class="row">
						<div class="col-md-4">
							<label class="control-label-input" for="inputSuccess">My {{calculator.pet}}'s weight is (lbs):</label>
						</div>
						<div class="col-md-7">
							<input class="form-control input-lg mb-md ng-valid ng-valid-number ng-dirty" type="number" ng-model="calculator.weight" ng-change="calculate();">
						</div>
					</div>
				</div><!-- end ngIf: calculator.activity -->							
				<!-- ngIf: calculator.weight -->
				<!--<div ng-if="calculator.weight" style="text-align: center;" class="ng-scope">
					<button type="button" class="btn btn-3d mr-xs mb-sm btn-secondary" ng-class="{&#39;btn-secondary&#39;: isActive(&#39;Decimal&#39;)}" ng-click="setActive(&#39;Decimal&#39;); calculate()">Decimal</button>
					<button type="button" class="btn btn-3d mr-xs mb-sm" ng-class="{&#39;btn-secondary&#39;: isActive(&#39;Fraction&#39;)}" ng-click="setActive(&#39;Fraction&#39;); calculate()">Fraction</button>
				</div>-->
				<!-- end ngIf: calculator.weight -->						
				<hr class="hr-tag2">
				<!-- ngIf: calculator.weight -->
				<div class="alert alert-default col-md-offset-2 col-md-8" ng-if="calculator.weight">
				  <div class="item item-avatar">
					<i class="icon ion-heart card-icon" style="padding-top:3px;"></i>
					<h1 class="">Recommended daily feeding:</h1>							
					<h2 class="ounces-check" ng-if="(active=='Decimal')">
					  <b ng-if="calculator.resultDecimalLb > 0">{{calculator.resultDecimalLb}} lb{{calculator.resultDecimalLb > 1 ? 's' : ''}}</b>
					  <b ng-if="calculator.resultDecimalLb > 0 && calculator.resultDecimalOz > 0">and</b>
					  <b ng-if="calculator.resultDecimalOz > 0">{{calculator.resultDecimalOz|number:1}} ounce{{calculator.resultDecimalOz > 1 ? 's' : ''}}</b>
					   of food per DAY
					</h2>							
					<h2 class="ounces-check" ng-if="(active=='Fraction')">
					  <b ng-if="calculator.resultFractionLb > 0">{{calculator.resultFractionLb}} lb{{calculator.resultFractionLb > 1 ? 's' : ''}}</b>
					  <b ng-if="calculator.resultFractionLb > 0 && (calculator.resultFractionOz > 0 || calculator.resultFractionOzF > 0)">and</b>
					  <b ng-if="(calculator.resultFractionOz > 0 || calculator.resultFractionOzF > 0)">{{calculator.resultFractionOz>0 ? calculator.resultFractionOz : ''}} {{calculator.resultFractionOzF>0 ? calculator.resultFractionOzF+"/16 of an ounce" : "ounce"+(calculator.resultFractionOz>1 ? 's' : '') }}</b>
					   of food per DAY
					</h2>								
					<p class="p-grey">
					  due to individual variances in pet metabolism and activity levels, this number should be used as a guideline only
					</p>
				  </div>
				</div><!-- end ngIf: calculator.weight -->						
			</form>
		</div>
	</div>	
